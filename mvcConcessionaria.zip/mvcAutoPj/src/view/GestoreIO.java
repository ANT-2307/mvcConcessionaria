package view;

import java.util.ArrayList;
import java.util.Scanner;

import model.Auto;

public class GestoreIO {

	@SuppressWarnings("resource")
	public String leggiString(String messaggio) {
		System.out.println(messaggio);
		Scanner input=new Scanner(System.in);
		return input.nextLine();
	}

	@SuppressWarnings("resource")
	public String leggiStringContinua(String messaggio) {
		System.out.print(messaggio);
		Scanner input=new Scanner(System.in);
		return input.nextLine();
	}

	@SuppressWarnings("resource")
	public int leggiInt(String messaggio) {
		System.out.println(messaggio);
		Scanner input=new Scanner(System.in);
		return Integer.parseInt(input.nextLine());
	}

	@SuppressWarnings("resource")
	public int leggiIntContinua(String messaggio) {
		System.out.print(messaggio);
		Scanner input=new Scanner(System.in);
		return Integer.parseInt(input.nextLine());
	}

	@SuppressWarnings("resource")
	public double leggiDouble(String messaggio) {
		System.out.println(messaggio);
		Scanner input=new Scanner(System.in);
		return Double.parseDouble(input.nextLine());
	}

	@SuppressWarnings("resource")
	public double leggiDoubleContinua(String messaggio) {
		System.out.print(messaggio);
		Scanner input=new Scanner(System.in);
		return Double.parseDouble(input.nextLine());
	}

	public void menu() {
		System.out.println("****MENU****");
		System.out.println("1) Inserisci un'auto");
		System.out.println("2) Visualizza le auto");
		System.out.println("3) Cerca un'auto");
		System.out.println("4) Modifica un auto");
		System.out.println("5) Cancella i dati");
		System.out.println("6) Esci");
		System.out.println("************");
	}

	public void formAuto(Auto auto) {
		auto.marca=leggiString("Inserisci la marca: ");
		auto.modello=leggiString("Inserisci il modello: ");
		auto.colore=leggiString("Inserisci il colore: ");
		auto.prezzo=leggiDouble("Inserisci il prezzo: ");
		auto.anno=leggiInt("Inserisci l'anno: ");
	}

	public void schedaAuto(Auto auto) {
		if (auto!=null) {
			System.out.println("************");
			System.out.println("ID: "+auto.id);
			System.out.println("MARCA: "+auto.marca);
			System.out.println("MODELLO: "+auto.modello);
			System.out.println("COLORE: "+auto.colore);
			System.out.println("PREZZO: "+auto.prezzo);
			System.out.println("ANNO: "+auto.anno);
		}
		else {
			System.err.println("Auto non trovata!");
		}
	}

	public void visualizzaDbAuto(ArrayList<Auto> dbAuto) {
		for (int i=0;i<dbAuto.size();i++) {
			schedaAuto(dbAuto.get(i));
		}
	}

	public void checkOp(String nomeOp,boolean risultatoOp) {
		if (risultatoOp) {
			System.out.println(nomeOp+" eseguito/a con successo!!!");
		}
		else {
			System.out.println(nomeOp+" annullato/a!!!");
		}
	}

	public Auto duplica(Auto autoOriginale){
		Auto autoTemp = new Auto();
		autoTemp.id=autoOriginale.id;
		autoTemp.marca=autoOriginale.marca;
		autoTemp.modello=autoOriginale.modello;
		autoTemp.colore=autoOriginale.colore;
		autoTemp.prezzo=autoOriginale.prezzo;
		autoTemp.anno = autoOriginale.anno;
		return autoTemp; 
	}

	public void formModifica(Auto autoSostitutiva) {
		System.out.println("************");
		autoSostitutiva.marca=leggiStringContinua("MARCA: "+autoSostitutiva.marca+"---> ");
		autoSostitutiva.modello=leggiStringContinua("MODELLO: "+autoSostitutiva.modello+"---> ");
		autoSostitutiva.colore=leggiStringContinua("COLORE: "+autoSostitutiva.colore+"---> ");
		autoSostitutiva.prezzo=leggiDoubleContinua("PREZZO: "+autoSostitutiva.prezzo+"---> ");
		autoSostitutiva.anno=leggiIntContinua("ANNO: "+autoSostitutiva.anno+"---> ");
	}


}
