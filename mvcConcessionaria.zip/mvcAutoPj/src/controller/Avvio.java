package controller;

import view.GestoreIO;

import java.util.ArrayList;

import model.Auto;


public class Avvio {

	public static void main(String[] args) {

		GestoreIO gio=new GestoreIO();
		CrudService crud=new CrudService();

		boolean flag=true;
		while(flag) {
			Auto auto=null;
			boolean risultatoOp=true;
			gio.menu();
			int scelta=gio.leggiInt("Scegli un opzione: ");
			switch(scelta) {
			case 1:
				auto=new Auto();
				gio.formAuto(auto);
				risultatoOp=crud.inserimentoAuto(auto);
				gio.checkOp("Inserimento", risultatoOp);
				gio.leggiString("Premi un tasto per continuare...");
				break;
			case 2:
				ArrayList<Auto> dbAuto=crud.getDbAuto();
				gio.visualizzaDbAuto(dbAuto);
				gio.leggiString("Premi un tasto per continuare...");
				break;
			case 3:
				int idCercata=gio.leggiInt("Inserisci l'id dell'auto che vuoi cercare: ");
				gio.schedaAuto(crud.getVeicolo(idCercata));
				gio.leggiString("Premi un tasto per continuare...");
				break;
			case 4:
				int idModifica=gio.leggiInt("Inserisci l'id dell'auto che vuoi modificare: ");
				if (crud.getVeicolo(idModifica)==null) {
					gio.leggiString("Auto non presente nel database! Premi un tasto per continuare...");
				}
				else {
					Auto autoTemp = gio.duplica(crud.getVeicolo(idModifica));
					gio.formModifica(autoTemp);
					String modifica=gio.leggiString("Confermi la modifica? (si/no)");
					if (modifica.equalsIgnoreCase("si")) {
						risultatoOp=crud.modificaAuto(autoTemp);
						gio.checkOp("Modifica", risultatoOp);
						gio.leggiString("Premi un tasto per continuare... ");
					}
					else if (modifica.equalsIgnoreCase("no")) {
						gio.leggiString("Modifica annullata! Premi un tasto per continuare...");
					}
					else {
						gio.leggiString("Risposta non contemplata! Premi un tasto per continuare...");
					}
				}
				break;
			case 5:
				int IdRimozione=gio.leggiInt("Inserisci l'id dell'auto che vuoi cancellare: ");
				risultatoOp=crud.removeVeicolo(IdRimozione);
				gio.checkOp("Rimozione", risultatoOp);
				gio.leggiString("Premi un tasto per continuare: ");
				break;
			case 6:
				gio.leggiString("Grazie per aver usato il nostro programma! Premi un tasto per continuare...");
				flag=false;
				break;
			default:
				gio.leggiString("Scelta non contemplata! Premi un tasto per continuare...");
				break;
			}

		}

	}

}
