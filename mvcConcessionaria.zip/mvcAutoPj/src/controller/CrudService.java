package controller;

import java.util.ArrayList;

import model.Auto;

public class CrudService {

	ArrayList<Auto> dbAuto=new ArrayList<>();

	int autoId=1;

	public boolean inserimentoAuto(Auto auto) {
		auto.id=autoId++;
		return dbAuto.add(auto);
	}

	public ArrayList<Auto> getDbAuto(){
		return dbAuto;
	}

	public Auto getVeicolo(int id) {
		for(int i=0;i<dbAuto.size();i++) {
			if(id==dbAuto.get(i).id) {
				return dbAuto.get(i);
			}
		}
		return null;
	}

	public boolean modificaAuto(Auto autoSostitutiva) {
		for(int i=0;i<dbAuto.size();i++) {
			if (autoSostitutiva.id==dbAuto.get(i).id) {
				dbAuto.set(i, autoSostitutiva);
				return true;
			}
		}
		return false;
	}


	public boolean removeVeicolo(int id) {
		for(int i=0;i<dbAuto.size();i++) {
			if(id==dbAuto.get(i).id) {
				dbAuto.remove(i);
				return true;
			}
		}
		return false;
	}
}