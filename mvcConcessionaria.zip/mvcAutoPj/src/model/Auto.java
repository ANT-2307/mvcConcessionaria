package model;

public class Auto { 
	
	public int id;
	public String marca;
	public String modello;
	public double prezzo;
	public int anno;
	public String colore;
	
}
